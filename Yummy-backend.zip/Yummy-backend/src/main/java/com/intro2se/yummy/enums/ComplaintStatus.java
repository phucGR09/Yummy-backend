package com.intro2se.yummy.enums;

public enum ComplaintStatus {
    WAITING_PROGRESS,
    IN_PROGRESS,
    COMPLETED,
    DENIED
}
