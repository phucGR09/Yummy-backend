package com.intro2se.yummy.enums;

public enum UserType {
    CUSTOMER,
    RESTAURANT_OWNER,
    DELIVERY_DRIVER,
    ADMIN
}
